<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
	<?php 
$message="";
  $emailErr=$message2="";
  include '../Controller/forgotcheck.php';
  include 'headpage.php';
  
  ?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

    <div style="height: 400px;margin: auto;background-color: #cce5ff;">
      <br><br><br>
      <fieldset style="width: 300px;height: 200px;margin: auto;">
        
    <legend><h2 style="color:darkblue;">Forgot Password</h2></legend>
    <br><br>
     <label for="email" style="color:darkblue;">Email:</label>
   &nbsp;&nbsp;<input type="text" name="email" id="email"><span style="color: red;"><?php echo $message;?></span><br><span style="color: red;"><?php echo $emailErr;?></span><br>
    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" name="submit" value="submit"><br>
    <span style="color: red;"><?php echo $message2;?></span>
   </fieldset>
 </div>
   

</body>
</html>