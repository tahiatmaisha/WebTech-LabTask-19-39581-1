
<!DOCTYPE html>
<html>
  <body>
<?php 
    include "nav.php";

?>
    <!-- [SEARCH FORM] -->
    <form method="post" action="controller/searchfood.php">
      <h1>SEARCH FOR Foods</h1>
      <input type="text" name="name" />
      <input type="submit" name="searchfood" value="Search"/>
    </form>


 
  </body>
</html>