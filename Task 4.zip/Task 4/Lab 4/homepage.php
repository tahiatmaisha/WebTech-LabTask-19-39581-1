<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<?php   require 'page.php'?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		
		<div style="height: 150px;"> <br><br><h3>&nbsp;&nbsp; Welcome to <i>X</i>company</h3></div>
		</form>
		<?php require'footer.php'?>
	

</body>
</html>