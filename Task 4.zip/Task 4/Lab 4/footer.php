<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
	<div style="border: 1px solid black;width:650px;height: 40px;" ><p style="text-align: center;">Copyright c-2017</p></div>

</body>
</html>