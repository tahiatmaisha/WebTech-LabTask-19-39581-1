<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
    fieldset{
      width: 400px;
      height: 300px;
     margin-left: 200px;
     
    }
  </style>
  
  <title></title>
</head>

<body>
  
  <?php
 
 session_start();
  
      $name = $email = $dob = $gender =  "";
      
      if(isset($_SESSION['uname']))
{
  $servername = "localhost";
$username = "root";
$password = "";
$dbname = "registration";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$sql="SELECT * FROM sellreg WHERE username='".$_SESSION['uname']."' AND password='".$_SESSION['pass']."'";
$result= $conn->query($sql);
if($result->num_rows>0)
{
  while($row=$result->fetch_assoc())
  {
  $name = $row["name"];
           $email = $row["email"];
           $gender = $row["gender"];
           $dob = $row["date"];
}
}
else
{
  $unamedb="";
  $passdb="";
}



$conn->close();

}

               
      
      ?>
      <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
        <?php 
          require'headpage.php';
        if (isset($_SESSION['uname'])) {
         echo" <div style='border:1px solid black;height:400px;margin:auto;width:1000px;'>
      <table style='height:400px;width:1000px;'><tr><td style='text-align:left;width:200px;background-color:lightblue;' ><p style='color:darkblue;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Account</p><hr style='width:100px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='dashboard.php' style='color:darkblue;'>DashBoard</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='view profile.php' style='color:darkblue;'>View Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='edit profile.php' style='color:darkblue;'>Edit Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='Change password.php' style='color:darkblue;'>Change Password</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='fileupload.php' style='color:darkblue;'>Change Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='../controller/logout.php' style='color:darkblue;'>Logout</a></td>
        <td style='text-align:left; background-color:white;'>


      <fieldset><legend style='color:darkblue;'><h2>View Profile</h2></legend>
        Name: $name <br><hr>
          Email: $email<br><hr> 
          Gender: $gender<br><hr>
          Date Of Birth: $dob<br><hr>


      <a href='edit profile.php'>Edit Profile</a>

  
  
  
  
  </fieldset>
</td>
</tr>
</table>
</div>";
}
   
?>

  
      
     





  </form>

</body>
</html>     
