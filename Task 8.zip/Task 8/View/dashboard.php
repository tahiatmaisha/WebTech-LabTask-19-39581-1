<!DOCTYPE html>
<html>
<head>
	
	<title></title>
</head>
<body>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
	<?php 
	
session_start();
include'headpage.php';
$home=$_SESSION['uname'];

if (isset($_SESSION['uname'])) {

	echo "<div style='border:1px solid black;height:400px;margin:auto;'><table style='height:400px;width:1000px;'><tr><td style='text-align:left;width:200px;'class='raisa'><p style='color:#ff0040;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Account</p><hr style='width:100px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='dashboard.php'style='color:#ff0040;'>DashBoard</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='addfood.php' style='color:#ff0040;'>Add Food</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='view profile.php' style='color:#ff0040;'>View Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='edit profile.php' style='color:#ff0040;'>Edit Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='Change password.php' style='color:#ff0040;'>Change Password</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='fileupload.php' style='color:#ff0040;'>Change Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='../controller/logout.php' style='color:#ff0040;'>Logout</a></td><td style='text-align:center;color:#ff0040;font-size:60px;'class='color'><h2>Welcome $home</h2></td></tr></table></div>";
	

} else {
	header("location:Login.php");
}


 ?>
</form>


</body>
</html>




