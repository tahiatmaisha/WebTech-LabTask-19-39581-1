

<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
    fieldset{
      width: 400px;
      height: 300px;
     margin-left: 200px;
     
    }
  </style>
   
  <title></title>
</head>

<body>
  <?php require('../Controller/editcheck.php');?>
  <form method="POST" action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>">
        
      <div style='border:1px solid black;height:400px;margin:auto;width: 1000px;'>
      <table style='height:400px;width:1000px;'>
        <tr>
          <td style='text-align:left;width:200px;background-color:lightblue;'>
            <p style='color:darkblue;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Account</p>
            <hr style='width:100px;'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='dashboard.php' style='color:darkblue;'>DashBoard</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='view profile.php' style='color:darkblue;'>View Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='edit profile.php' style='color:darkblue;'>Edit Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='Change password.php' style='color:darkblue;'>Change Password</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='fileupload.php' style='color:darkblue;'>Change Profile</a><br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <a href='../Controller/logout.php' style='color:darkblue;'>Logout</a>
          </td>
          <td style='text-align:left;'>
            <fieldset>   
              <legend style='color:darkblue;'><h2>Edit Profile</h2></legend>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                Name: <input type='text' name='name'value='<?php echo $name ?>'> 
                <br><br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                Email: <input type='text' name='email'value='<?php echo $email ?>'>
                <br><br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp; 
                Gender: <input type='text' name='gender'value='<?php echo $gender ?>'>
                <br><br>
                Date Of Birth: <input type='text' name='date'value='<?php echo $dob ?>'>
                <br><br>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;    
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 
                <input type='submit' name='submit' value="Edit">
          
            </fieldset>
          </td>
        </tr>
      </table>
   </div>
</form>



</body>
</html>