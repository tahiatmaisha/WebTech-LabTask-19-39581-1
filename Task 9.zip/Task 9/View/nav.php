 <ul>
        <li><a href="addfood.php"> Add Food</a></li>
        <li><a href="showAllfoods.php"> Show all foods</a></li>
        <li><a href="search.php"> Search foods</a></li>
    </ul>