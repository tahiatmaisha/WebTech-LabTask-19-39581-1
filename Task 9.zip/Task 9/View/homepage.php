<!DOCTYPE html>
<html>
<head>
	<style type="text/css">

	</style>
		<title></title>
</head>
<body>
	<?php   require 'headpage.php'?>
	<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
		
		<div style="height:500px;margin: auto; background-image: url('pic1.jpg');background-repeat: no-repeat;background-size: 1500px;"> <br><br><br><br><br><br><br><br><br><h1 style="text-align: center;color:darkblue;font-size: 50px;">&nbsp; Welcome</h1></div>
		</form>
		
	

</body>
</html>