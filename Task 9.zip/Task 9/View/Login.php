<!DOCTYPE html>
<html>
<head>
  <style type="text/css">
    fieldset{
      width: 500px;
      height: 300px;
     
      margin-left: 850px;
    }
  </style>
  
<body>
  <?php 

  $unameErr=$passErr=$message2="";
  require 'headpage.php'; 
   require_once("../javascript/Lscript.php");
  require_once("../controller/Lcheck.php");
   
  
?>
  

<form method="post" action="" onsubmit="return validation()">
  <div style="height: 500px;margin: auto;background-image: url('pic2.jpg');background-repeat: no-repeat;background-size: 800px; ">
    <br><br><br><br>
 <fieldset>
    <legend style='color:darkblue;'><h2>Login</h2></legend>
    <label for="uname" style='color:darkblue;'>User name:</label>
    <input type="text" name="uname" id="uname"value="<?php if(isset($_COOKIE['uname'])){echo $_COOKIE['uname']; } ?>"onkeydown="checkUsername()" onblur="checkUsername ()"><br><span style="color: red;" id="unameErr"><?php if(!empty($_GET['unameErr'])){echo $_GET['unameErr'];} ?></span><br>
    <label for="pass" style='color:darkblue;'>Password:</label>
   
    &nbsp;&nbsp;&nbsp;<input type="Password" name="pass" id="pass" value="<?php if(isset($_COOKIE['pass'])) {echo $_COOKIE['pass'];} ?>"onkeydown="checkPassword()" onblur="checkPassword()"><br><span style="color:red;" id="passErr"><?php if(!empty($_GET['passErr'])){echo $_GET['passErr'];} ?></span><hr>
   <input type="checkbox" name="remember" id="remember">
   <label for="remember" style='color:darkblue;'>Remember me</label><br><span style="color:red;"><?php if(!empty($_POST['remember'])) {echo $message;}else{echo $error;}?></span><br>
   <input type="submit" name="Lsubmit" value="submit">

   <a href="forgot.php" style='color:darkblue;'>Forgot Password?</a>
   &nbsp;<a href="registration.php" style='color:darkblue;'>Sign Up</a>
   <br><span  style="color:red;"><?php echo $message2?></span>



  </fieldset><br>
</div>


  

  

</form>
</body>
</html>