<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" type="text/css" href="stylist.css">
</head>
<body>

  <form action="upload.php" method="post" enctype="multipart/form-data">
  <fieldset>
    <legend><h2>Profile Picture</h2></legend>
    <img src="pic.jpg"><br>
  <input type="file" name="fileToUpload" id="fileToUpload"><br><hr>
  <input type="submit" value="submit" name="submit">
  </fieldset><br>
</form>


</body>
</html>